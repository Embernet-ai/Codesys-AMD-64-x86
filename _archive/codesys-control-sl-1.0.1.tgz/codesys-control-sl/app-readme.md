# CODESYS Control SL

Run the industry-standard IEC 61131-3 SoftPLC on Kubernetes.


### Quick Start

1. **Install**: Deploy this chart to your cluster.
2. **Connect**: Open the CODESYS IDE and scan for the Gateway at the Pod's IP (Port 1217).
3. **Program**: Deploy your PLC logic.
4. **Visualize**: Access the WebVisu at `http://<node-ip>:8080/webvisu.htm`.

### Key Features
- **Demo Mode**: Runs for 2 hours without a license (perfect for testing).
- **Persistence**: Retains logic and variables across restarts.
- **Standards**: Supports OPC UA, EtherCAT, and PROFINET.
